﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.DL;

namespace signupapp.BL
{
    class faculty
    {
        private string name;
        private string qualification;
        private string subject;
        private int age;

        public faculty(string name, string qualification, string subject, int age)
        {
            this.name = name;
            this.qualification = qualification;
            this.subject = subject;
            this.age = age;
        }


        public string Name { get => name; set => name = value; }
        public string Qualification { get => qualification; set => qualification = value; }
        public string Subject { get => subject; set => subject = value; }
        public int Age { get => age; set => age = value; }
        public static bool checkalphabet(string word)
        {
            int number = 0;
            for (int z = 0; z < word.Length; z++)
            {
                number = word[z];


                if (word[z] == '\0')
                {
                    break;
                }
                else if (number >= 65 && number <= 90)
                {
                    continue;
                }
                else if (number >= 97 && number <= 122)
                {
                    continue;
                }
                else if (number == 32)
                {
                    continue;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        public static bool isValidFaculty(faculty user)
        {
            foreach (faculty storedUser in facultyDL.Facultylist)
            {
                if (storedUser.Name == user.Name && storedUser.qualification == user.qualification && storedUser.Subject == user.subject && storedUser.age == user.age)
                {
                    return true;
                }
            }
            return false;
        }
    }

   
    


    
}
