﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace signupapp.BL
{
    class marks
    {
        private string name;
        private float oop;
        private float dld;
        private float psychology;
        private float qt;
        private float mvc;
        private float aps;
        private float cs;
        private float total;

        public marks(string name, float oop, float dld, float psychology, float qt, float mvc, float aps, float cs, float total)
        {
            this.Name = name;
            this.Oop = oop;
            this.Dld = dld;
            this.Psychology = psychology;
            this.Qt = qt;
            this.Mvc = mvc;
            this.Aps = aps;
            this.Cs = cs;
            this.Total = total;
        }

        public string Name { get => name; set => name = value; }
        public float Oop { get => oop; set => oop = value; }
        public float Dld { get => dld; set => dld = value; }
        public float Psychology { get => psychology; set => psychology = value; }
        public float Qt { get => qt; set => qt = value; }
        public float Mvc { get => mvc; set => mvc = value; }
        public float Aps { get => aps; set => aps = value; }
        public float Cs { get => cs; set => cs = value; }
        public float Total { get => total; set => total = value; }
    }

    
}
