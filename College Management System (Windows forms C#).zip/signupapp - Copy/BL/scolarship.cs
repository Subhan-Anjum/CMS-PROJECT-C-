﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.DL;

namespace signupapp.BL
{
    class scolarship
    {
        private string name;
        private float gpa;
        private string father_status;
        private string type;
        private string info = "has applied for scholarship";

        public scolarship(string name, float gpa, string father_status, string type, string info)
        {
            this.Name = name;
            this.Gpa = gpa;
            this.Father_status = father_status;
            this.Type = type;
            this.Info = info;
        }

        public string Name { get => name; set => name = value; }
        public float Gpa { get => gpa; set => gpa = value; }
        public string Father_status { get => father_status; set => father_status = value; }
        public string Type { get => type; set => type = value; }
        public string Info { get => info; set => info = value; }
        public static bool isValidname(scolarship user)
        {
            foreach (scolarship storedUser in scolarshipDL.Scolarshiplist)
            {
                if (storedUser.Name == user.Name&&storedUser.Type==user.Type)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
