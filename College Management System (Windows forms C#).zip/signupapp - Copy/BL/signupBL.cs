﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.DL;

namespace signupapp.BL
{
    class signupBL
    {
        private string UserName;
        private string Password;
        private string Role;
     

        public string UserName1 { get => UserName; set => UserName = value; }
        public string Password1 { get => Password; set => Password = value; }
        public string Role1 { get => Role; set => Role = value; }
      

        public  List<marks> studentsdata = new List<marks>();

        public signupBL(string UserName,string Password,string Role)
        {
            this.UserName1 = UserName;
            this.Password1 = Password;
            this.Role1 = Role;
        }
        public signupBL(string UserName,string Password)
        {
            this.UserName1 = UserName;
            this.Password1 = Password;
            this.Role1 = "NA";
        }
      
        public bool isAdmin()
        {
            if (Role1 == "admin")
            {
                return true;
            }
            return false;
        }
        public static int dataindex = 0;
        public static int Checksignin(signupBL user)
        {
            for (int i=0;i<SignupDL.datalist.Count;i++)
            {
                if (SignupDL.datalist[i].UserName1 == user.UserName1 &&
                SignupDL.datalist[i].Password1 == user.Password1)
                {
                   
                    if (SignupDL.datalist[i].Role1 == "admin")
                    {
                        return 1;
                    }
                    if (SignupDL.datalist[i].Role1 == "student")
                    {
                        dataindex = i;
                        return 2;
                    }
                    else
                    {
                        return 3;
                    }

                }
            }
            return 0;

        }

        public static bool isValid(signupBL user)
        {
            foreach (signupBL storedUser in SignupDL.datalist)
            {
                if (storedUser.UserName == user.UserName &&storedUser.Role==user.Role)
                {
                    return true;
                }
            }
            return false;
        }



    }

    class CopyOfsignupBL
    {
        private string UserName;
        private string Password;
        private string Role;


        public string UserName1 { get => UserName; set => UserName = value; }
        public string Password1 { get => Password; set => Password = value; }
        public string Role1 { get => Role; set => Role = value; }


        public List<marks> studentsdata = new List<marks>();

        public CopyOfsignupBL(string UserName, string Password, string Role)
        {
            this.UserName1 = UserName;
            this.Password1 = Password;
            this.Role1 = Role;
        }
        public CopyOfsignupBL(string UserName, string Password)
        {
            this.UserName1 = UserName;
            this.Password1 = Password;
            this.Role1 = "NA";
        }

        public bool isAdmin()
        {
            if (Role1 == "admin")
            {
                return true;
            }
            return false;
        }
        public static int dataindex = 0;
        public static int Checksignin(CopyOfsignupBL user)
        {
            for (int i = 0; i < SignupDL.datalist.Count; i++)
            {
                if (SignupDL.datalist[i].UserName1 == user.UserName1 &&
                SignupDL.datalist[i].Password1 == user.Password1)
                {

                    if (SignupDL.datalist[i].Role1 == "admin")
                    {
                        return 1;
                    }
                    if (SignupDL.datalist[i].Role1 == "student")
                    {
                        dataindex = i;
                        return 2;
                    }
                    else
                    {
                        return 3;
                    }

                }
            }
            return 0;

        }

        //public static bool isValid(CopyOfsignupBL user)
        //{
        //    foreach (CopyOfsignupBL storedUser in SignupDL.datalist)
        //    {
        //        if (storedUser.UserName == user.UserName && storedUser.Role == user.Role)
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}



    }

}

