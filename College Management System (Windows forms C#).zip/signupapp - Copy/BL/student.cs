﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.DL;
namespace signupapp.BL
{
   public class student
    {
        private string name;
        private float matric;
        private long cnic;
        private int age;
        private string course;

        public student(string name, float matric, long cnic, int age, string course)
        {
            this.Name = name;
            this.Matric = matric;
            this.Cnic = cnic;
            this.Age = age;
            this.Course = course;
        }

        public string Name { get => name; set => name = value; }
        public float Matric { get => matric; set => matric = value; }
        public long Cnic { get => cnic; set => cnic = value; }
        public int Age { get => age; set => age = value; }
        public string Course { get => course; set => course = value; }
        public static void sorting()
        {
            studentDL.Studentlist = studentDL.Studentlist.OrderByDescending(o => o.Matric).ToList();
        }
		 public static bool checkalphabet(string word)
		{
			int number = 0;
			for (int z = 0; z < word.Length; z++)
			{
				number = word[z];


				if (word[z] == '\0')
				{
					break;
				}
				else if (number >= 65 && number <= 90)
				{
					continue;
				}
				else if (number >= 97 && number <= 122)
				{
					continue;
				}
				else if (number == 32)
				{
					continue;
				}
				else
				{
					return false;
				}
			}
			return true;
		}
		public static double checkcnic(long number)
		{
			int countc = 0;
			for (long a = number; a != 0; a = a / 10)
			{
				countc++;
			}
			return countc;
		}
        public static bool isValidStudent(student user)
        {
            foreach (student storedUser in studentDL.Studentlist)
            {
                if (storedUser.Name == user.Name && storedUser.Cnic == user.Cnic)
                {
                    return true;
                }
            }
            return false;
        }




    }

    public class CopyOfstudent
    {
        private string name;
        private float matric;
        private long cnic;
        private int age;
        private string course;

        public CopyOfstudent(string name, float matric, long cnic, int age, string course)
        {
            this.Name = name;
            this.Matric = matric;
            this.Cnic = cnic;
            this.Age = age;
            this.Course = course;
        }

        public string Name { get => name; set => name = value; }
        public float Matric { get => matric; set => matric = value; }
        public long Cnic { get => cnic; set => cnic = value; }
        public int Age { get => age; set => age = value; }
        public string Course { get => course; set => course = value; }
        public static void sorting()
        {
            studentDL.Studentlist = studentDL.Studentlist.OrderByDescending(o => o.Matric).ToList();
        }
        public static bool checkalphabet(string word)
        {
            int number = 0;
            for (int z = 0; z < word.Length; z++)
            {
                number = word[z];


                if (word[z] == '\0')
                {
                    break;
                }
                else if (number >= 65 && number <= 90)
                {
                    continue;
                }
                else if (number >= 97 && number <= 122)
                {
                    continue;
                }
                else if (number == 32)
                {
                    continue;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        public static double checkcnic(long number)
        {
            int countc = 0;
            for (long a = number; a != 0; a = a / 10)
            {
                countc++;
            }
            return countc;
        }




    }

    public class CopyOfCopyOfstudent
    {
        private string name;
        private float matric;
        private long cnic;
        private int age;
        private string course;

        public CopyOfCopyOfstudent(string name, float matric, long cnic, int age, string course)
        {
            this.Name = name;
            this.Matric = matric;
            this.Cnic = cnic;
            this.Age = age;
            this.Course = course;
        }

        public string Name { get => name; set => name = value; }
        public float Matric { get => matric; set => matric = value; }
        public long Cnic { get => cnic; set => cnic = value; }
        public int Age { get => age; set => age = value; }
        public string Course { get => course; set => course = value; }
        public static void sorting()
        {
            studentDL.Studentlist = studentDL.Studentlist.OrderByDescending(o => o.Matric).ToList();
        }
        public static bool checkalphabet(string word)
        {
            int number = 0;
            for (int z = 0; z < word.Length; z++)
            {
                number = word[z];


                if (word[z] == '\0')
                {
                    break;
                }
                else if (number >= 65 && number <= 90)
                {
                    continue;
                }
                else if (number >= 97 && number <= 122)
                {
                    continue;
                }
                else if (number == 32)
                {
                    continue;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        public static double checkcnic(long number)
        {
            int countc = 0;
            for (long a = number; a != 0; a = a / 10)
            {
                countc++;
            }
            return countc;
        }




    }
}
