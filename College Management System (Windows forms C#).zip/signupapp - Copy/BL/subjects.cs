﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace signupapp.BL
{
    class subjects
    {
        private string name;
        private string sub1;
        private string sub2;
        private string sub3;
        private string sub4;
        private string sub5;
        private string sub6;
        private string sub7;

        public subjects(string name, string sub1, string sub2, string sub3, string sub4, string sub5, string sub6, string sub7)
        {
            this.Name = name;
            this.Sub1 = sub1;
            this.Sub2 = sub2;
            this.Sub3 = sub3;
            this.Sub4 = sub4;
            this.Sub5 = sub5;
            this.Sub6 = sub6;
            this.Sub7 = sub7;
        }

        public string Name { get => name; set => name = value; }
        public string Sub1 { get => sub1; set => sub1 = value; }
        public string Sub2 { get => sub2; set => sub2 = value; }
        public string Sub3 { get => sub3; set => sub3 = value; }
        public string Sub4 { get => sub4; set => sub4 = value; }
        public string Sub5 { get => sub5; set => sub5 = value; }
        public string Sub6 { get => sub6; set => sub6 = value; }
        public string Sub7 { get => sub7; set => sub7 = value; }
    }

    class CopyOfsubjects
    {
        private string name;
        private string sub1;
        private string sub2;
        private string sub3;
        private string sub4;
        private string sub5;
        private string sub6;
        private string sub7;

        public CopyOfsubjects(string name, string sub1, string sub2, string sub3, string sub4, string sub5, string sub6, string sub7)
        {
            this.Name = name;
            this.Sub1 = sub1;
            this.Sub2 = sub2;
            this.Sub3 = sub3;
            this.Sub4 = sub4;
            this.Sub5 = sub5;
            this.Sub6 = sub6;
            this.Sub7 = sub7;
        }

        public string Name { get => name; set => name = value; }
        public string Sub1 { get => sub1; set => sub1 = value; }
        public string Sub2 { get => sub2; set => sub2 = value; }
        public string Sub3 { get => sub3; set => sub3 = value; }
        public string Sub4 { get => sub4; set => sub4 = value; }
        public string Sub5 { get => sub5; set => sub5 = value; }
        public string Sub6 { get => sub6; set => sub6 = value; }
        public string Sub7 { get => sub7; set => sub7 = value; }
    }
}
