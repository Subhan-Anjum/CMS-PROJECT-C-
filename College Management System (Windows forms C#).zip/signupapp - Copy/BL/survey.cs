﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.DL;

namespace signupapp.BL
{
    class survey
    {
        private string name;
        private string sUrvey;

        public survey(string name, string sUrvey)
        {
            this.Name = name;
            this.SUrvey = sUrvey;
        }

        public string Name { get => name; set => name = value; }
        public string SUrvey { get => sUrvey; set => sUrvey = value; }
        public static bool isValidname(survey user)
        {
            foreach (survey storedUser in surveyDL.SurveyList)
            {
                if (storedUser.Name == user.Name)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
