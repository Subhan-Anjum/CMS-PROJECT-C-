﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.BL;
using System.IO;

namespace signupapp.DL
{
    class MarksDL
    {
        private static List<marks> markslist = new List<marks>();

        public static void addintolist(marks data)
        {

            SignupDL.datalist[signupBL.dataindex].studentsdata.Add(data);
        }
        internal static List<marks> Markslist { get => markslist; set => markslist = value; }
        public static void store(int idx,marks sts)
        {
            string path = "marks.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(idx+","+sts.Name + "," +sts.Oop+","+ sts.Dld + "," + sts.Psychology + "," + sts.Qt + "," + sts.Mvc + "," + sts.Aps + "," + sts.Cs + "," + sts.Total);
            file.Flush();
            file.Close();
        }
        
        public static void read(int idx)
        {
            string path = "marks.txt";
            StreamReader file = new StreamReader(path);
            string record;
           
                if (File.Exists(path))
                {
                    while ((record = file.ReadLine()) != null)
                    {
                        string[] splittedrecord = record.Split(',');
                    try
                    {
                        int tempind = int.Parse(splittedrecord[0]);
                        if (tempind == idx)
                        {
                            string name = splittedrecord[1];
                            float m1 = float.Parse(splittedrecord[2]);
                            float m2 = float.Parse(splittedrecord[3]);
                            float m3 = float.Parse(splittedrecord[4]);
                            float m4 = float.Parse(splittedrecord[5]);
                            float m5 = float.Parse(splittedrecord[6]);
                            float m6 = float.Parse(splittedrecord[7]);
                            float m7 = float.Parse(splittedrecord[8]);
                            float m8 = float.Parse(splittedrecord[9]);
                            marks sts = new marks(name, m1, m2, m3, m4, m5, m6, m7, m8);
                            addintolist(sts);
                        }
                    }
                    catch(Exception exp)
                    {
                        MessageBox.Show(exp.Message);
                    }
                    }
                    file.Close();
                }
            
            
        }

        public static void delemarks(marks stu)
        {
            for (int idx = 0; idx < Markslist.Count; idx++)
            {
                if (Markslist[idx].Name == stu.Name&&Markslist[idx].Total==stu.Total)
                {
                    Markslist.RemoveAt(idx);
                }
            }
        }
        public static void editstudentmarksfromlist(marks previous, marks updt)
        {
            foreach (marks stu in Markslist)
            {
                if (stu.Name == previous.Name && stu.Total==previous.Total)
                {
                    stu.Name = updt.Name;
                    stu.Oop = updt.Oop;
                    stu.Dld = updt.Dld;
                    stu.Psychology = updt.Psychology;
                    stu.Qt = updt.Qt;
                    stu.Mvc = updt.Mvc;
                    stu.Aps = updt.Aps;
                    stu.Cs = updt.Cs;
                    stu.Total = updt.Total;
                }
            }
        }
        public static void storealldataintofile(string path)
        {
            //string path = "marks.txt";
            StreamWriter file = new StreamWriter(path, true);
            foreach(marks sts in markslist)
            {
            file.WriteLine(GenerateMarks.setidx() + "," + sts.Name + "," + sts.Oop + "," + sts.Dld + "," + sts.Psychology + "," + sts.Qt + "," + sts.Mvc + "," + sts.Aps + "," + sts.Cs + "," + sts.Total);
            }
            file.Flush();
            file.Close();
        }

    }
}
