﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.BL;
using System.IO;

namespace signupapp.DL
{
    class SignupDL
    {
        public static List<signupBL> datalist = new List<signupBL>();
        public static  void adduserintolist(signupBL data)
        {
            datalist.Add(data);

        }
        public static void store(signupBL newUser)
        {
            string path = "login.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(newUser.UserName1 + "," + newUser.Password1 + "," + newUser.Role1);
            file.Flush();
            file.Close();
        }
        public static void read(string path)
        {

            StreamReader file = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string name = splittedRecord[0];
                    string pass = splittedRecord[1];
                    string role = splittedRecord[2];
                    signupBL newUser = new signupBL(name, pass, role);
                    datalist.Add(newUser);
                }
            }
            file.Close();

        }
    }
}
