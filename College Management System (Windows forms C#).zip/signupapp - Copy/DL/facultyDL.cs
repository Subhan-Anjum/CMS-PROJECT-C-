﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using signupapp.BL;

namespace signupapp.DL
{
    class facultyDL
    {
        private static List<faculty> facultylist = new List<faculty>();

        internal static List<faculty> Facultylist { get => facultylist; set => facultylist = value; }
        public static void store(faculty user)
        {
            string path = "faculty.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.Name + "," + user.Qualification+ "," + user.Subject+","+user.Age);
            file.Flush();
            file.Close();
        }
        public static void read(string path)
        {
            StreamReader file = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    string name = splittedrecord[0];
                   string qual = splittedrecord[1];
                    string sub = splittedrecord[2];
                    int age = int.Parse(splittedrecord[3]);
                    faculty fct = new faculty(name, qual, sub, age);
                    facultylist.Add(fct);
                    
                }
            }
            file.Close();
        }
        public static void deletefacultyfromfile(faculty fct)
        {
            for (int idx = 0; idx < Facultylist.Count; idx++)
            {
                if (Facultylist[idx].Name == fct.Name && Facultylist[idx].Qualification == fct.Qualification)
                {
                    Facultylist.RemoveAt(idx);
                }
            }
        }
        public static void storealldataintofile()
        {
            string path = "faculty.txt";
            StreamWriter file = new StreamWriter(path);
            foreach (faculty fct in Facultylist)
            {
                file.WriteLine(fct.Name + "," + fct.Qualification + "," + fct.Subject + "," + fct.Age);
            }
            file.Flush();
            file.Close();
        }
    }
}
