﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.BL;
using System.IO;

namespace signupapp.DL
{
    class scolarshipDL
    {
        private static List<scolarship> scolarshiplist = new List<scolarship>();

        internal static List<scolarship> Scolarshiplist { get => scolarshiplist; set => scolarshiplist = value; }
        public static void store(scolarship user)
        {
           
                string path = "scholarship.txt";
                StreamWriter file = new StreamWriter(path, true);
                file.WriteLine(user.Name+","+user.Gpa+","+user.Father_status+","+user.Type+","+user.Info);
                file.Flush();
                file.Close();
            
        }
        public static void read(string path)
        {
            StreamReader file = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    string name = splittedrecord[0];
                    float gpa = float.Parse(splittedrecord[1]);
                    string fatherstatus = splittedrecord[2];
                    string type = splittedrecord[3];
                    string info = splittedrecord[4];
                    scolarship stu = new scolarship(name,gpa,fatherstatus,type,info);
                    scolarshiplist.Add(stu);
                }
            }
            file.Close();
        }
    }
}
