﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using signupapp.BL;

namespace signupapp.DL
{
    class studentDL
    {
        private static List<student> studentlist = new List<student>();

        internal static List<student> Studentlist { get => studentlist; set => studentlist = value; }
        public static void store(student users)
        {
            string path = "students.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(users.Name + "," + users.Matric + "," + users.Cnic + "," + users.Age + "," + users.Course);
            file.Flush();
            file.Close();
        }
        public static void read(string path)
        {
            StreamReader file = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    string name = splittedrecord[0];
                    float matric = float.Parse(splittedrecord[1]);
                    long cnic = long.Parse(splittedrecord[2]);
                    int age = int.Parse(splittedrecord[3]);
                    string course = splittedrecord[4];
                    student stu = new student(name, matric, cnic, age, course);
                    studentlist.Add(stu);
                }
            }
            file.Close();
        }
        public static void deletestudentfromfile(student stu)
        {
            for(int idx=0; idx<studentlist.Count; idx++)
            {
                if (studentlist[idx].Name == stu.Name && studentlist[idx].Cnic == stu.Cnic)
                {
                    studentlist.RemoveAt(idx);
                }
            }
        }
        public static void editstudentfromlist(student previous,student updt)
        {
            foreach(student stu in studentlist)
            {
                if (stu.Name == previous.Name && stu.Cnic == previous.Cnic)
                {
                    stu.Name = updt.Name;
                    stu.Matric = updt.Matric;
                    stu.Cnic = updt.Cnic;
                    stu.Age = updt.Age;
                    stu.Course = updt.Course;
                }
            }
        }
        public static void storealldataintofile(string path)
        {
            //string path = "students.txt";
            StreamWriter file = new StreamWriter(path);
            foreach (student stu in studentlist)
            {
                file.WriteLine(stu.Name + "," + stu.Matric + "," + stu.Cnic + "," + stu.Age + "," + stu.Course);
            }
            file.Flush();
            file.Close();
        }
      
    }
}
