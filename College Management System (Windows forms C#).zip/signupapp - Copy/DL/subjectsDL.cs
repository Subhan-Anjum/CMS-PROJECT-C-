﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using signupapp.BL;
using System.Threading.Tasks;
using System.IO;

namespace signupapp.DL
{
    class subjectsDL
    {
        private static List<subjects> subjectlist = new List<subjects>();

        internal static List<subjects> Subjectlist { get => subjectlist; set => subjectlist = value; }
        public static void store(subjects stu)
        {
            string path = "subjects.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(stu.Name + "," + stu.Sub1 + "," + stu.Sub2 + "," + stu.Sub3 +","+ stu.Sub4 + "," + stu.Sub5 + "," + stu.Sub6 + "," + stu.Sub7);
            file.Flush();
            file.Close();
        }
        public static void read(string path)
        {
            StreamReader file = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    string name = splittedrecord[0];
                    string s1 = splittedrecord[1];
                    string s2 = splittedrecord[2];
                    string s3 = splittedrecord[3];
                    string s4 = splittedrecord[4];
                    string s5 = splittedrecord[5];
                    string s6 = splittedrecord[6];
                    string s7 = splittedrecord[7];
                    subjects data = new subjects(name, s1, s2, s3, s4, s5, s6, s7);
                    Subjectlist.Add(data);
                }
            }
            file.Close();
        }
    }
}
