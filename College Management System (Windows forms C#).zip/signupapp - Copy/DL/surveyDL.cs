﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using signupapp.BL;
using System.IO;

namespace signupapp.DL
{
    class surveyDL
    {
        private static List<survey> surveyList = new List<survey>();

        internal static List<survey> SurveyList { get => surveyList; set => surveyList = value; }
        public static void store(survey users)
        {
            string path = "survey.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(users.Name + "," + users.SUrvey);
            file.Flush();
            file.Close();
        }
        public static void read(string path)
        {
            StreamReader file = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedrecord = record.Split(',');
                    string name = splittedrecord[0];
                    string surveys = splittedrecord[1];
                    survey stu = new survey(name, surveys);
                    surveyList.Add(stu);
                }
            }
            file.Close();
        }
    }
}
