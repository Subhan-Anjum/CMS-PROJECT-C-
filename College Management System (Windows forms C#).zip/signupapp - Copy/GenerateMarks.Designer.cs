﻿
namespace signupapp
{
    partial class GenerateMarks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GenerateMarks));
            this.label1 = new System.Windows.Forms.Label();
            this.lblnamemarks = new System.Windows.Forms.Label();
            this.lbloop = new System.Windows.Forms.Label();
            this.lblDLD = new System.Windows.Forms.Label();
            this.lblPsy = new System.Windows.Forms.Label();
            this.lblQT = new System.Windows.Forms.Label();
            this.lblMVC = new System.Windows.Forms.Label();
            this.lblAPs = new System.Windows.Forms.Label();
            this.lblCS = new System.Windows.Forms.Label();
            this.lblTotl = new System.Windows.Forms.Label();
            this.txtnamemarks = new System.Windows.Forms.TextBox();
            this.txtoop = new System.Windows.Forms.TextBox();
            this.txtCS = new System.Windows.Forms.TextBox();
            this.txtst = new System.Windows.Forms.TextBox();
            this.txtMVC = new System.Windows.Forms.TextBox();
            this.txtQT = new System.Windows.Forms.TextBox();
            this.txtpsy = new System.Windows.Forms.TextBox();
            this.txtdld = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnadmarksintolist = new System.Windows.Forms.Button();
            this.txttotals = new System.Windows.Forms.TextBox();
            this.btnexit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(313, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Generate Marks";
            // 
            // lblnamemarks
            // 
            this.lblnamemarks.AutoSize = true;
            this.lblnamemarks.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblnamemarks.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnamemarks.ForeColor = System.Drawing.Color.White;
            this.lblnamemarks.Location = new System.Drawing.Point(12, 120);
            this.lblnamemarks.Name = "lblnamemarks";
            this.lblnamemarks.Size = new System.Drawing.Size(88, 35);
            this.lblnamemarks.TabIndex = 1;
            this.lblnamemarks.Text = "Name";
            // 
            // lbloop
            // 
            this.lbloop.AutoSize = true;
            this.lbloop.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lbloop.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloop.ForeColor = System.Drawing.Color.White;
            this.lbloop.Location = new System.Drawing.Point(130, 120);
            this.lbloop.Name = "lbloop";
            this.lbloop.Size = new System.Drawing.Size(80, 35);
            this.lbloop.TabIndex = 2;
            this.lbloop.Text = "OOP";
            // 
            // lblDLD
            // 
            this.lblDLD.AutoSize = true;
            this.lblDLD.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblDLD.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDLD.ForeColor = System.Drawing.Color.White;
            this.lblDLD.Location = new System.Drawing.Point(240, 120);
            this.lblDLD.Name = "lblDLD";
            this.lblDLD.Size = new System.Drawing.Size(79, 35);
            this.lblDLD.TabIndex = 3;
            this.lblDLD.Text = "DLD";
            // 
            // lblPsy
            // 
            this.lblPsy.AutoSize = true;
            this.lblPsy.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblPsy.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPsy.ForeColor = System.Drawing.Color.White;
            this.lblPsy.Location = new System.Drawing.Point(363, 120);
            this.lblPsy.Name = "lblPsy";
            this.lblPsy.Size = new System.Drawing.Size(73, 35);
            this.lblPsy.TabIndex = 4;
            this.lblPsy.Text = "PSY";
            // 
            // lblQT
            // 
            this.lblQT.AutoSize = true;
            this.lblQT.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblQT.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQT.ForeColor = System.Drawing.Color.White;
            this.lblQT.Location = new System.Drawing.Point(477, 120);
            this.lblQT.Name = "lblQT";
            this.lblQT.Size = new System.Drawing.Size(58, 35);
            this.lblQT.TabIndex = 5;
            this.lblQT.Text = "QT";
            this.lblQT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMVC
            // 
            this.lblMVC.AutoSize = true;
            this.lblMVC.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblMVC.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMVC.ForeColor = System.Drawing.Color.White;
            this.lblMVC.Location = new System.Drawing.Point(567, 120);
            this.lblMVC.Name = "lblMVC";
            this.lblMVC.Size = new System.Drawing.Size(86, 35);
            this.lblMVC.TabIndex = 6;
            this.lblMVC.Text = "MVC";
            this.lblMVC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblAPs
            // 
            this.lblAPs.AutoSize = true;
            this.lblAPs.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblAPs.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAPs.ForeColor = System.Drawing.Color.White;
            this.lblAPs.Location = new System.Drawing.Point(669, 120);
            this.lblAPs.Name = "lblAPs";
            this.lblAPs.Size = new System.Drawing.Size(72, 35);
            this.lblAPs.TabIndex = 7;
            this.lblAPs.Text = "APS";
            this.lblAPs.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCS
            // 
            this.lblCS.AutoSize = true;
            this.lblCS.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCS.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCS.ForeColor = System.Drawing.Color.White;
            this.lblCS.Location = new System.Drawing.Point(794, 120);
            this.lblCS.Name = "lblCS";
            this.lblCS.Size = new System.Drawing.Size(54, 35);
            this.lblCS.TabIndex = 8;
            this.lblCS.Text = "CS";
            this.lblCS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblCS.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblTotl
            // 
            this.lblTotl.AutoSize = true;
            this.lblTotl.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblTotl.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotl.ForeColor = System.Drawing.Color.White;
            this.lblTotl.Location = new System.Drawing.Point(903, 120);
            this.lblTotl.Name = "lblTotl";
            this.lblTotl.Size = new System.Drawing.Size(116, 35);
            this.lblTotl.TabIndex = 9;
            this.lblTotl.Text = "TOTAL";
            this.lblTotl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtnamemarks
            // 
            this.txtnamemarks.Location = new System.Drawing.Point(18, 194);
            this.txtnamemarks.Name = "txtnamemarks";
            this.txtnamemarks.Size = new System.Drawing.Size(104, 22);
            this.txtnamemarks.TabIndex = 10;
            // 
            // txtoop
            // 
            this.txtoop.Location = new System.Drawing.Point(128, 194);
            this.txtoop.Name = "txtoop";
            this.txtoop.Size = new System.Drawing.Size(104, 22);
            this.txtoop.TabIndex = 11;
            this.txtoop.TextChanged += new System.EventHandler(this.txtoop_TextChanged);
            // 
            // txtCS
            // 
            this.txtCS.Location = new System.Drawing.Point(783, 194);
            this.txtCS.Name = "txtCS";
            this.txtCS.Size = new System.Drawing.Size(104, 22);
            this.txtCS.TabIndex = 12;
            this.txtCS.TextChanged += new System.EventHandler(this.txtCS_TextChanged);
            // 
            // txtst
            // 
            this.txtst.Location = new System.Drawing.Point(675, 194);
            this.txtst.Name = "txtst";
            this.txtst.Size = new System.Drawing.Size(104, 22);
            this.txtst.TabIndex = 13;
            this.txtst.TextChanged += new System.EventHandler(this.txtst_TextChanged);
            // 
            // txtMVC
            // 
            this.txtMVC.Location = new System.Drawing.Point(571, 194);
            this.txtMVC.Name = "txtMVC";
            this.txtMVC.Size = new System.Drawing.Size(104, 22);
            this.txtMVC.TabIndex = 14;
            this.txtMVC.TextChanged += new System.EventHandler(this.txtMVC_TextChanged);
            // 
            // txtQT
            // 
            this.txtQT.Location = new System.Drawing.Point(465, 194);
            this.txtQT.Name = "txtQT";
            this.txtQT.Size = new System.Drawing.Size(104, 22);
            this.txtQT.TabIndex = 15;
            this.txtQT.TextChanged += new System.EventHandler(this.txtQT_TextChanged);
            // 
            // txtpsy
            // 
            this.txtpsy.Location = new System.Drawing.Point(354, 194);
            this.txtpsy.Name = "txtpsy";
            this.txtpsy.Size = new System.Drawing.Size(104, 22);
            this.txtpsy.TabIndex = 16;
            this.txtpsy.TextChanged += new System.EventHandler(this.txtpsy_TextChanged);
            // 
            // txtdld
            // 
            this.txtdld.Location = new System.Drawing.Point(237, 194);
            this.txtdld.Name = "txtdld";
            this.txtdld.Size = new System.Drawing.Size(104, 22);
            this.txtdld.TabIndex = 17;
            this.txtdld.TextChanged += new System.EventHandler(this.txtdld_TextChanged);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(890, 194);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 17);
            this.lblTotal.TabIndex = 18;
            // 
            // btnadmarksintolist
            // 
            this.btnadmarksintolist.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnadmarksintolist.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadmarksintolist.Location = new System.Drawing.Point(816, 387);
            this.btnadmarksintolist.Name = "btnadmarksintolist";
            this.btnadmarksintolist.Size = new System.Drawing.Size(145, 55);
            this.btnadmarksintolist.TabIndex = 20;
            this.btnadmarksintolist.Text = "Add";
            this.btnadmarksintolist.UseVisualStyleBackColor = false;
            this.btnadmarksintolist.Click += new System.EventHandler(this.btnadmarksintolist_Click);
            // 
            // txttotals
            // 
            this.txttotals.Location = new System.Drawing.Point(909, 194);
            this.txttotals.Name = "txttotals";
            this.txttotals.ReadOnly = true;
            this.txttotals.Size = new System.Drawing.Size(104, 22);
            this.txttotals.TabIndex = 21;
            this.txttotals.TextChanged += new System.EventHandler(this.txttotals_TextChanged);
            // 
            // btnexit
            // 
            this.btnexit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.ForeColor = System.Drawing.SystemColors.MenuText;
            this.btnexit.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnexit.Location = new System.Drawing.Point(79, 477);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(300, 47);
            this.btnexit.TabIndex = 23;
            this.btnexit.Text = "Exit to Previous page";
            this.btnexit.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(510, 400);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(233, 54);
            this.button1.TabIndex = 24;
            this.button1.Text = "Generate Total";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // GenerateMarks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1031, 536);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.txttotals);
            this.Controls.Add(this.btnadmarksintolist);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.txtdld);
            this.Controls.Add(this.txtpsy);
            this.Controls.Add(this.txtQT);
            this.Controls.Add(this.txtMVC);
            this.Controls.Add(this.txtst);
            this.Controls.Add(this.txtCS);
            this.Controls.Add(this.txtoop);
            this.Controls.Add(this.txtnamemarks);
            this.Controls.Add(this.lblTotl);
            this.Controls.Add(this.lblCS);
            this.Controls.Add(this.lblAPs);
            this.Controls.Add(this.lblMVC);
            this.Controls.Add(this.lblQT);
            this.Controls.Add(this.lblPsy);
            this.Controls.Add(this.lblDLD);
            this.Controls.Add(this.lbloop);
            this.Controls.Add(this.lblnamemarks);
            this.Controls.Add(this.label1);
            this.Name = "GenerateMarks";
            this.Text = "0";
            this.Load += new System.EventHandler(this.txtAPS_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblnamemarks;
        private System.Windows.Forms.Label lbloop;
        private System.Windows.Forms.Label lblDLD;
        private System.Windows.Forms.Label lblPsy;
        private System.Windows.Forms.Label lblQT;
        private System.Windows.Forms.Label lblMVC;
        private System.Windows.Forms.Label lblAPs;
        private System.Windows.Forms.Label lblCS;
        private System.Windows.Forms.Label lblTotl;
        private System.Windows.Forms.TextBox txtnamemarks;
        private System.Windows.Forms.TextBox txtoop;
        private System.Windows.Forms.TextBox txtCS;
        private System.Windows.Forms.TextBox txtst;
        private System.Windows.Forms.TextBox txtMVC;
        private System.Windows.Forms.TextBox txtQT;
        private System.Windows.Forms.TextBox txtpsy;
        private System.Windows.Forms.TextBox txtdld;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnadmarksintolist;
        private System.Windows.Forms.TextBox txttotals;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button button1;
    }
}