﻿
namespace signupapp
{
    partial class frmregidtersubjects
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmregidtersubjects));
            this.label1 = new System.Windows.Forms.Label();
            this.chckoop = new System.Windows.Forms.CheckBox();
            this.chckmvc = new System.Windows.Forms.CheckBox();
            this.chckpsy = new System.Windows.Forms.CheckBox();
            this.chckdld = new System.Windows.Forms.CheckBox();
            this.chckcs = new System.Windows.Forms.CheckBox();
            this.chckaps = new System.Windows.Forms.CheckBox();
            this.chckqt = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtnamerst = new System.Windows.Forms.TextBox();
            this.btnprvs = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Highlight;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.label1.Location = new System.Drawing.Point(247, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Register Subjects";
            // 
            // chckoop
            // 
            this.chckoop.AutoSize = true;
            this.chckoop.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.chckoop.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckoop.Location = new System.Drawing.Point(56, 194);
            this.chckoop.Name = "chckoop";
            this.chckoop.Size = new System.Drawing.Size(110, 42);
            this.chckoop.TabIndex = 1;
            this.chckoop.Text = "OOp";
            this.chckoop.UseVisualStyleBackColor = false;
            this.chckoop.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chckmvc
            // 
            this.chckmvc.AutoSize = true;
            this.chckmvc.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.chckmvc.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckmvc.Location = new System.Drawing.Point(56, 358);
            this.chckmvc.Name = "chckmvc";
            this.chckmvc.Size = new System.Drawing.Size(103, 42);
            this.chckmvc.TabIndex = 2;
            this.chckmvc.Text = "Mvc";
            this.chckmvc.UseVisualStyleBackColor = false;
            this.chckmvc.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // chckpsy
            // 
            this.chckpsy.AutoSize = true;
            this.chckpsy.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.chckpsy.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckpsy.Location = new System.Drawing.Point(56, 301);
            this.chckpsy.Name = "chckpsy";
            this.chckpsy.Size = new System.Drawing.Size(89, 42);
            this.chckpsy.TabIndex = 3;
            this.chckpsy.Text = "Psy";
            this.chckpsy.UseVisualStyleBackColor = false;
            this.chckpsy.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // chckdld
            // 
            this.chckdld.AutoSize = true;
            this.chckdld.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.chckdld.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckdld.Location = new System.Drawing.Point(56, 253);
            this.chckdld.Name = "chckdld";
            this.chckdld.Size = new System.Drawing.Size(92, 42);
            this.chckdld.TabIndex = 4;
            this.chckdld.Text = "Dld";
            this.chckdld.UseVisualStyleBackColor = false;
            this.chckdld.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // chckcs
            // 
            this.chckcs.AutoSize = true;
            this.chckcs.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.chckcs.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckcs.Location = new System.Drawing.Point(210, 358);
            this.chckcs.Name = "chckcs";
            this.chckcs.Size = new System.Drawing.Size(83, 42);
            this.chckcs.TabIndex = 5;
            this.chckcs.Text = "CS";
            this.chckcs.UseVisualStyleBackColor = false;
            this.chckcs.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // chckaps
            // 
            this.chckaps.AutoSize = true;
            this.chckaps.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.chckaps.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckaps.Location = new System.Drawing.Point(210, 301);
            this.chckaps.Name = "chckaps";
            this.chckaps.Size = new System.Drawing.Size(95, 42);
            this.chckaps.TabIndex = 6;
            this.chckaps.Text = "Aps";
            this.chckaps.UseVisualStyleBackColor = false;
            this.chckaps.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // chckqt
            // 
            this.chckqt.AutoSize = true;
            this.chckqt.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.chckqt.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckqt.Location = new System.Drawing.Point(210, 253);
            this.chckqt.Name = "chckqt";
            this.chckqt.Size = new System.Drawing.Size(88, 42);
            this.chckqt.TabIndex = 7;
            this.chckqt.Text = "QT";
            this.chckqt.UseVisualStyleBackColor = false;
            this.chckqt.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button1.Location = new System.Drawing.Point(613, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 35);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 38);
            this.label2.TabIndex = 9;
            this.label2.Text = "Name";
            // 
            // txtnamerst
            // 
            this.txtnamerst.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnamerst.Location = new System.Drawing.Point(180, 132);
            this.txtnamerst.Name = "txtnamerst";
            this.txtnamerst.Size = new System.Drawing.Size(200, 34);
            this.txtnamerst.TabIndex = 10;
            // 
            // btnprvs
            // 
            this.btnprvs.BackColor = System.Drawing.Color.Red;
            this.btnprvs.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprvs.Location = new System.Drawing.Point(285, 406);
            this.btnprvs.Name = "btnprvs";
            this.btnprvs.Size = new System.Drawing.Size(296, 49);
            this.btnprvs.TabIndex = 11;
            this.btnprvs.Text = "Exit to Previous Page";
            this.btnprvs.UseVisualStyleBackColor = false;
            this.btnprvs.Click += new System.EventHandler(this.btnprvs_Click);
            // 
            // frmregidtersubjects
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnprvs);
            this.Controls.Add(this.txtnamerst);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chckqt);
            this.Controls.Add(this.chckaps);
            this.Controls.Add(this.chckcs);
            this.Controls.Add(this.chckdld);
            this.Controls.Add(this.chckpsy);
            this.Controls.Add(this.chckmvc);
            this.Controls.Add(this.chckoop);
            this.Controls.Add(this.label1);
            this.Name = "frmregidtersubjects";
            this.Text = "frmregidtersubjects";
            this.Load += new System.EventHandler(this.frmregidtersubjects_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chckoop;
        private System.Windows.Forms.CheckBox chckmvc;
        private System.Windows.Forms.CheckBox chckpsy;
        private System.Windows.Forms.CheckBox chckdld;
        private System.Windows.Forms.CheckBox chckcs;
        private System.Windows.Forms.CheckBox chckaps;
        private System.Windows.Forms.CheckBox chckqt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtnamerst;
        private System.Windows.Forms.Button btnprvs;
    }
}